#  Daewoo Transport Booking System

A PHP + MySQL project for bus ticket booking. Users can view routes, times, and book seats with fare calculation.

## 🚫 License

This project is **not open source**.

The code is visible for educational viewing only.  
Use, modification, or redistribution without permission is **prohibited**.

📩 For licensing inquiries, contact: saifullahawan939@gmail.com
